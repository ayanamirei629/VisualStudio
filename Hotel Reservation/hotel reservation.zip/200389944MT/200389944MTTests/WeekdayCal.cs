﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using _200389944MT;

namespace _200389944MTTests
{
    [TestClass]
    public class WeekdayCal
    {
        [TestMethod]
        public void TestWeekdayCal()
        {
            try
            {
                Reservations r = new Reservations();
                double result = r.weekdayCalculation(double.MaxValue, 324239999);
                Console.WriteLine(result);
            }
            catch (StackOverflowException)
            {
                Assert.IsTrue(true);
                return;
            }
            Assert.Fail();
        }
        [TestMethod]
        public void TestNegativePrice()
        {
            Reservations r = new Reservations();
            double result = r.weekendCalculation(-2, 324239999);
            Assert.IsTrue(result == 0);
        }
        [TestMethod]
        public void TestNegativeDay()
        {
            Reservations r = new Reservations();
            double result = r.weekendCalculation(235, -4);
            Assert.IsTrue(result == 0);
        }
    }
}
