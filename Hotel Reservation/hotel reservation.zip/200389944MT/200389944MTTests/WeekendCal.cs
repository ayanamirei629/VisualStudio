﻿using System;
using _200389944MT;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace _200389944MTTests
{
    [TestClass]
    public class WeekendCal
    {
        [TestMethod]
        public void TestWeekendCal()
        {
            try
            {
                Reservations r = new Reservations();
                double result = r.weekendCalculation(double.MaxValue, 324239999);
                Console.WriteLine(result);
            }
            catch (StackOverflowException)
            {
                Assert.IsTrue(true);
                return;
            }
            Assert.Fail();
        }
        [TestMethod]
        public void TestNegativePrice()
        {
            Reservations r = new Reservations();
            double result = r.weekendCalculation(-2, 324239999);
            Assert.IsTrue(result == 0);
        }
        [TestMethod]
        public void TestNegativeDay()
        {
            Reservations r = new Reservations();
            double result = r.weekendCalculation(21314, -2);
            Assert.IsTrue(result == 0);
        }
    }
}
