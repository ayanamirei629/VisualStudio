﻿using System;
using _200389944MT;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace _200389944MTTests
{
    [TestClass]
    public class combination
    {
        [TestMethod]
        public void TestCombination()
        {
            try
            {
                Reservations r = new Reservations();
                double result1 = r.weekdayCalculation(double.MaxValue, 324239999);
                double result2 = r.weekendCalculation(123456789012345673248888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888889012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890.0, 324239999);
                double result = result1 + result2;
            }
            catch (StackOverflowException)
            {
                Assert.IsTrue(true);
                return;
            }
            Assert.Fail();
        }

        [TestMethod]
        public void TestNegativePrice()
        {
            Reservations r = new Reservations();
            double result1 = r.weekdayCalculation(-2, 324239999);
            Assert.IsTrue(result1 == 0);
        }
        [TestMethod]
        public void TestNegativeDay()
        {
            Reservations r = new Reservations();
            double result1 = r.weekdayCalculation(123124, -2);
            Assert.IsTrue(result1 == 0);
        }
    }
}
