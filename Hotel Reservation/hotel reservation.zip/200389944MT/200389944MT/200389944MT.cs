﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _200389944MT
{
    public partial class Reservations : Form
    {
        public Reservations()
        {
            InitializeComponent();
        }

        //close the application when exit is clicked
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //button calculate display click when enter is clicked
        private void btnCalculate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnCalculate.PerformClick();
                // these last two lines will stop the beep sound
                e.SuppressKeyPress = true;
                e.Handled = true;
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            //initialize arrivalDate to store input arrivalDate, departureDate to store input departureDate, currentDate present the date when processing in the loop, now for the date today;
            //initialize weekdayPrice to store price for weekday, weekend price to store price for weekend, totalPrice stores total price need to be paid
            //initialize string begindate to store the information of arrivalDate
            //initialize numOfNight stores total nights stays in the hotel, numOfWeekdays stores num of nights belongs to weekday, numOfWeekend stores num of nights belongs to weekend
            DateTime arrivalDate, departureDate, currentDate,now;
            double weekdayPrice,weekendPrice,totalPrice;
            String beginDate;
            int numOfNights,numOfWeekdays,numOfWeekend;
            numOfNights = 0;
            numOfWeekdays = 0;
            numOfWeekend = 0;
            weekdayPrice = 159.00;
            weekendPrice = 210.00;
            totalPrice = 0;
            now = DateTime.Now;
            arrivalDate = dtpArrivalDate.Value.Date;
            departureDate = dtpDepartureDate.Value.Date;
            //if departureDate is not after today, it is not a valid reservation
            if (departureDate <= now) {
                MessageBox.Show("input is wrong, end date should after today because it is for reservation");
                return;
            }
            //if departureDate is not after arrivalDate, it is not a valid reservation
            if (arrivalDate >= departureDate) {
                MessageBox.Show("input is wrong, start date should be before end date");
                return;
            }
            //store the beginning date information
            currentDate = dtpArrivalDate.Value.Date;
            beginDate = arrivalDate.DayOfWeek.ToString() + ", " + arrivalDate.ToString("MMMM") + " " + arrivalDate.Day.ToString() +
                ", " + arrivalDate.Year.ToString();
            //do the loop while currentDate is not reach departureDate, check if it is weekend night each time, store the value and add a day to currentDate
            while (currentDate < departureDate) {
                if (IsWeekend(currentDate))
                {
                    numOfWeekend += 1;
                }
                else {
                    numOfWeekdays += 1;
                }
                numOfNights += 1;
                currentDate = currentDate.AddDays(1);
            }
            //Calculate for total price and output to the textbox
            totalPrice = weekdayCalculation(weekdayPrice, numOfWeekdays) + weekendCalculation(weekendPrice, numOfWeekend);
            txtTotalPrice.Text = totalPrice.ToString("C2");
            //output the numOfNights to the textbox
            txtNumOfNights.Text = numOfNights.ToString();
            //calculate & output the average price pernight
            txtAvgPerNight.Text = CalculateAvgPrice(totalPrice, numOfNights).ToString("c2");
            //display the message
            MessageBox.Show(String.Format("Your total is {0:C2} for {1:D} nights beginning {2}. Please enjoy your stay!", totalPrice, numOfNights,
                beginDate));
        }

        //check if the date is friday or saturday
        public bool IsWeekend(DateTime CurrentDate) {
            if (CurrentDate.DayOfWeek.ToString() == "Saturday" || CurrentDate.DayOfWeek.ToString() == "Friday") {
                return true;
            }
            return false;
        }

        //calculate total price for weekday
        public double weekdayCalculation(double weekdayPrice, int numOfWeekdays) {
            if (weekdayPrice * numOfWeekdays >= Double.MaxValue)
                    throw new StackOverflowException("Too big of a reservation!");
            if (numOfWeekdays < 0 || weekdayPrice < 0) {
                MessageBox.Show("input is wrong,cannot be negative");
                return 0;
            }
            return weekdayPrice * numOfWeekdays;
        }

        //calculate total price for weekend
        public double weekendCalculation(double weekendPrice, int numOfWeekend)
        {
            if (weekendPrice * numOfWeekend >= Double.MaxValue)
                throw new StackOverflowException("Too big of a reservation!");
            if (numOfWeekend < 0 || weekendPrice < 0)
            {
                MessageBox.Show("input is wrong,cannot be negative");
                return 0;
            }
            return weekendPrice * numOfWeekend;
        }

        //calculate average price for reservation
        public double CalculateAvgPrice(double TotalPrice, int numOfNights) {
            if (TotalPrice >= Double.MaxValue)
                throw new StackOverflowException("Too big of a reservation!");
            if (TotalPrice < 0 || numOfNights < 0)
            {
                MessageBox.Show("input is wrong,cannot be negative");
                return 0;
            }
            return TotalPrice / numOfNights;
        }
    }
}
