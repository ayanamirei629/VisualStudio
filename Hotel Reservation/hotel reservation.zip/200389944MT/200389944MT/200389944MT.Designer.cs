﻿namespace _200389944MT
{
    partial class Reservations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtpDepartureDate = new System.Windows.Forms.DateTimePicker();
            this.lblArriveDate = new System.Windows.Forms.Label();
            this.lblDepDate = new System.Windows.Forms.Label();
            this.lblNumOfNights = new System.Windows.Forms.Label();
            this.lblTotalPrice = new System.Windows.Forms.Label();
            this.lblAvgPerNight = new System.Windows.Forms.Label();
            this.dtpArrivalDate = new System.Windows.Forms.DateTimePicker();
            this.txtNumOfNights = new System.Windows.Forms.TextBox();
            this.txtTotalPrice = new System.Windows.Forms.TextBox();
            this.txtAvgPerNight = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dtpDepartureDate
            // 
            this.dtpDepartureDate.Location = new System.Drawing.Point(395, 138);
            this.dtpDepartureDate.Name = "dtpDepartureDate";
            this.dtpDepartureDate.Size = new System.Drawing.Size(486, 20);
            this.dtpDepartureDate.TabIndex = 0;
            // 
            // lblArriveDate
            // 
            this.lblArriveDate.AutoSize = true;
            this.lblArriveDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lblArriveDate.Location = new System.Drawing.Point(189, 66);
            this.lblArriveDate.Name = "lblArriveDate";
            this.lblArriveDate.Size = new System.Drawing.Size(103, 24);
            this.lblArriveDate.TabIndex = 1;
            this.lblArriveDate.Text = "Arrival date";
            // 
            // lblDepDate
            // 
            this.lblDepDate.AutoSize = true;
            this.lblDepDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lblDepDate.Location = new System.Drawing.Point(189, 134);
            this.lblDepDate.Name = "lblDepDate";
            this.lblDepDate.Size = new System.Drawing.Size(134, 24);
            this.lblDepDate.TabIndex = 2;
            this.lblDepDate.Text = "Departure date";
            // 
            // lblNumOfNights
            // 
            this.lblNumOfNights.AutoSize = true;
            this.lblNumOfNights.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lblNumOfNights.Location = new System.Drawing.Point(189, 213);
            this.lblNumOfNights.Name = "lblNumOfNights";
            this.lblNumOfNights.Size = new System.Drawing.Size(154, 24);
            this.lblNumOfNights.TabIndex = 3;
            this.lblNumOfNights.Text = "Number of nights";
            // 
            // lblTotalPrice
            // 
            this.lblTotalPrice.AutoSize = true;
            this.lblTotalPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lblTotalPrice.Location = new System.Drawing.Point(189, 290);
            this.lblTotalPrice.Name = "lblTotalPrice";
            this.lblTotalPrice.Size = new System.Drawing.Size(98, 24);
            this.lblTotalPrice.TabIndex = 4;
            this.lblTotalPrice.Text = "Total price";
            // 
            // lblAvgPerNight
            // 
            this.lblAvgPerNight.AutoSize = true;
            this.lblAvgPerNight.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lblAvgPerNight.Location = new System.Drawing.Point(189, 369);
            this.lblAvgPerNight.Name = "lblAvgPerNight";
            this.lblAvgPerNight.Size = new System.Drawing.Size(174, 24);
            this.lblAvgPerNight.TabIndex = 5;
            this.lblAvgPerNight.Text = "Avg. price per night";
            // 
            // dtpArrivalDate
            // 
            this.dtpArrivalDate.Location = new System.Drawing.Point(395, 70);
            this.dtpArrivalDate.Name = "dtpArrivalDate";
            this.dtpArrivalDate.Size = new System.Drawing.Size(486, 20);
            this.dtpArrivalDate.TabIndex = 6;
            // 
            // txtNumOfNights
            // 
            this.txtNumOfNights.Location = new System.Drawing.Point(395, 216);
            this.txtNumOfNights.Name = "txtNumOfNights";
            this.txtNumOfNights.ReadOnly = true;
            this.txtNumOfNights.Size = new System.Drawing.Size(486, 20);
            this.txtNumOfNights.TabIndex = 7;
            // 
            // txtTotalPrice
            // 
            this.txtTotalPrice.Location = new System.Drawing.Point(395, 294);
            this.txtTotalPrice.Name = "txtTotalPrice";
            this.txtTotalPrice.ReadOnly = true;
            this.txtTotalPrice.Size = new System.Drawing.Size(486, 20);
            this.txtTotalPrice.TabIndex = 8;
            // 
            // txtAvgPerNight
            // 
            this.txtAvgPerNight.Location = new System.Drawing.Point(395, 373);
            this.txtAvgPerNight.Name = "txtAvgPerNight";
            this.txtAvgPerNight.ReadOnly = true;
            this.txtAvgPerNight.Size = new System.Drawing.Size(486, 20);
            this.txtAvgPerNight.TabIndex = 9;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(247, 484);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(227, 60);
            this.btnCalculate.TabIndex = 10;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            this.btnCalculate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnCalculate_KeyDown);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(724, 484);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(227, 60);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1315, 625);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtAvgPerNight);
            this.Controls.Add(this.txtTotalPrice);
            this.Controls.Add(this.txtNumOfNights);
            this.Controls.Add(this.dtpArrivalDate);
            this.Controls.Add(this.lblAvgPerNight);
            this.Controls.Add(this.lblTotalPrice);
            this.Controls.Add(this.lblNumOfNights);
            this.Controls.Add(this.lblDepDate);
            this.Controls.Add(this.lblArriveDate);
            this.Controls.Add(this.dtpDepartureDate);
            this.Name = "Form1";
            this.Text = "Reservations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpDepartureDate;
        private System.Windows.Forms.Label lblArriveDate;
        private System.Windows.Forms.Label lblDepDate;
        private System.Windows.Forms.Label lblNumOfNights;
        private System.Windows.Forms.Label lblTotalPrice;
        private System.Windows.Forms.Label lblAvgPerNight;
        private System.Windows.Forms.DateTimePicker dtpArrivalDate;
        private System.Windows.Forms.TextBox txtNumOfNights;
        private System.Windows.Forms.TextBox txtTotalPrice;
        private System.Windows.Forms.TextBox txtAvgPerNight;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
    }
}

